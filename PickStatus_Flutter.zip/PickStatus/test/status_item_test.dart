import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:pickstatus/models/status_item.dart';

void main() {
  test('detects image status from extension', () {
    final file = File('/tmp/status.jpg');
    final item = StatusItem.fromFile(file);
    expect(item.isVideo, false);
    expect(item.extension, 'JPG');
  });

  test('detects video status from extension', () {
    final file = File('/tmp/status.mp4');
    final item = StatusItem.fromFile(file);
    expect(item.isVideo, true);
    expect(item.extension, 'MP4');
  });
}
