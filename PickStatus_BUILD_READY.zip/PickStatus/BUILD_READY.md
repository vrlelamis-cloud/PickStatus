# PickStatus — Build Ready V3

Cette version corrige la configuration Gradle Flutter qui empêchait le plugin
`dev.flutter.flutter-plugin-loader:1.0.0` d'être trouvé.

Le fichier `android/settings.gradle.kts` inclut désormais correctement :
`$flutterSdkPath/packages/flutter_tools/gradle`.

Le workflow recrée les fichiers Android manquants avec `flutter create`, puis
vérifie explicitement la présence de cette configuration avant `flutter pub get`,
`flutter analyze`, `flutter test` et `flutter build apk --release`.
