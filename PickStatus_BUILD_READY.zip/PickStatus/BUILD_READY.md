PickStatus — project prepared for cloud APK build.
The GitHub workflow generates the Android wrapper before compiling.
