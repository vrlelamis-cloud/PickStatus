import 'package:flutter/material.dart';
import 'services/status_service.dart';
import 'services/settings_service.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = SettingsService();
  await settings.load();

  runApp(PickStatusApp(settings: settings));
}

class PickStatusApp extends StatefulWidget {
  final SettingsService settings;

  const PickStatusApp({super.key, required this.settings});

  @override
  State<PickStatusApp> createState() => _PickStatusAppState();
}

class _PickStatusAppState extends State<PickStatusApp> {
  ThemeMode get themeMode {
    switch (widget.settings.theme) {
      case AppThemeMode.light:
        return ThemeMode.light;
      case AppThemeMode.dark:
        return ThemeMode.dark;
      case AppThemeMode.system:
        return ThemeMode.system;
    }
  }

  void refreshTheme() => setState(() {});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF25D366);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PickStatus',
      themeMode: themeMode,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xFFF7F9F8),
        appBarTheme: const AppBarTheme(centerTitle: false),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
        ),
      ),
      home: HomeScreen(
        settings: widget.settings,
        statusService: StatusService(),
        onThemeChanged: refreshTheme,
      ),
    );
  }
}
