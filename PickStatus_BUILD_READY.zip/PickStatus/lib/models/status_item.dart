import 'dart:io';
import 'package:path/path.dart' as p;

enum StatusType { image, video }

class StatusItem {
  final String sourcePath;
  final String name;
  final DateTime modified;
  final int size;
  final StatusType type;

  const StatusItem({
    required this.sourcePath,
    required this.name,
    required this.modified,
    required this.size,
    required this.type,
  });

  bool get isVideo => type == StatusType.video;

  String get extension => p.extension(name).replaceFirst('.', '').toUpperCase();

  Future<bool> get exists async => File(sourcePath).exists();

  factory StatusItem.fromFile(File file) {
    final ext = p.extension(file.path).toLowerCase();
    final videoExt = {'.mp4', '.3gp', '.mkv', '.webm', '.mov', '.avi'};
    return StatusItem(
      sourcePath: file.path,
      name: p.basename(file.path),
      modified: file.statSync().modified,
      size: file.lengthSync(),
      type: videoExt.contains(ext) ? StatusType.video : StatusType.image,
    );
  }
}
