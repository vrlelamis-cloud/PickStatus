import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/services.dart';
import '../models/status_item.dart';

class StatusService {
  static const _channel = MethodChannel('pickstatus/native');

  static const _imageExtensions = {
    '.jpg', '.jpeg', '.png', '.webp', '.gif', '.heic'
  };

  static const _videoExtensions = {
    '.mp4', '.3gp', '.mkv', '.webm', '.mov', '.avi'
  };

  Future<bool> hasStorageAccess() async {
    if (!Platform.isAndroid) return false;
    return (await Permission.manageExternalStorage.isGranted);
  }

  Future<bool> requestStorageAccess() async {
    if (!Platform.isAndroid) return true;
    var status = await Permission.manageExternalStorage.status;
    if (!status.isGranted) {
      status = await Permission.manageExternalStorage.request();
    }
    return status.isGranted;
  }

  List<Directory> _candidateDirectories() {
    const root = '/storage/emulated/0';
    return [
      Directory('$root/Android/media/com.whatsapp/WhatsApp/Media/.Statuses'),
      Directory('$root/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses'),
      Directory('$root/WhatsApp/Media/.Statuses'),
      Directory('$root/WhatsApp Business/Media/.Statuses'),
    ];
  }

  Future<List<StatusItem>> scan({bool includeBusiness = true}) async {
    final access = await hasStorageAccess();
    if (!access) {
      throw const StorageAccessException(
        'Accès au stockage non accordé. Autorisez PickStatus à gérer les fichiers.',
      );
    }

    final results = <StatusItem>[];
    final directories = _candidateDirectories();

    for (var i = 0; i < directories.length; i++) {
      final isBusiness = i == 1 || i == 3;
      if (isBusiness && !includeBusiness) continue;

      final dir = directories[i];
      try {
        if (!await dir.exists()) continue;

        await for (final entity in dir.list(followLinks: false)) {
          if (entity is! File) continue;
          final name = p.basename(entity.path);
          if (name.startsWith('.')) continue;

          final ext = p.extension(name).toLowerCase();
          if (!_imageExtensions.contains(ext) &&
              !_videoExtensions.contains(ext)) {
            continue;
          }

          try {
            final item = StatusItem.fromFile(entity);
            results.add(item);
          } catch (_) {
            // Ignore a file that disappears or becomes unreadable while scanning.
          }
        }
      } on FileSystemException {
        // One WhatsApp installation may be absent or inaccessible.
      }
    }

    final unique = <String, StatusItem>{};
    for (final item in results) {
      unique[item.sourcePath] = item;
    }

    final sorted = unique.values.toList()
      ..sort((a, b) => b.modified.compareTo(a.modified));
    return sorted;
  }

  Future<Directory> getSaveDirectory() async {
    Directory? external;
    try {
      external = await getExternalStorageDirectory();
    } catch (_) {
      external = null;
    }

    // Public Pictures/PickStatus is preferred so the saved media is easy to find.
    final publicPictures = Directory('/storage/emulated/0/Pictures/PickStatus');
    try {
      await publicPictures.create(recursive: true);
      return publicPictures;
    } catch (_) {
      if (external == null) rethrow;
      final fallback = Directory(p.join(external.path, 'PickStatus'));
      await fallback.create(recursive: true);
      return fallback;
    }
  }

  Future<File> saveStatus(StatusItem item) async {
    final source = File(item.sourcePath);
    if (!await source.exists()) {
      throw const StatusOperationException('Le statut n’est plus disponible.');
    }

    final directory = await getSaveDirectory();
    final baseName = p.basenameWithoutExtension(item.name);
    final ext = p.extension(item.name);
    var destination = File(p.join(directory.path, '$baseName$ext'));

    if (await destination.exists()) {
      final sameSize = await destination.length() == await source.length();
      if (sameSize) return destination;

      final stamp = DateTime.now().millisecondsSinceEpoch;
      destination = File(p.join(directory.path, '${baseName}_$stamp$ext'));
    }

    await source.copy(destination.path);

    if (Platform.isAndroid) {
      try {
        await _channel.invokeMethod<void>('scanFile', {
          'path': destination.path,
        });
      } catch (_) {
        // Media scanner failure does not invalidate the saved file.
      }
    }

    return destination;
  }

  Future<bool> deleteSaved(String path) async {
    final file = File(path);
    if (!await file.exists()) return true;
    try {
      await file.delete();
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<List<File>> savedFiles() async {
    final directory = await getSaveDirectory();
    if (!await directory.exists()) return [];

    final files = <File>[];
    await for (final entity in directory.list(followLinks: false)) {
      if (entity is File) {
        final ext = p.extension(entity.path).toLowerCase();
        if (_imageExtensions.contains(ext) || _videoExtensions.contains(ext)) {
          files.add(entity);
        }
      }
    }

    files.sort((a, b) {
      try {
        return b.statSync().modified.compareTo(a.statSync().modified);
      } catch (_) {
        return 0;
      }
    });
    return files;
  }

  Future<int> savedCount() async => (await savedFiles()).length;

  Future<void> deleteAllSaved() async {
    final directory = await getSaveDirectory();
    if (!await directory.exists()) return;

    await for (final entity in directory.list(followLinks: false)) {
      if (entity is File) {
        try {
          await entity.delete();
        } catch (_) {}
      }
    }
  }
}

class StorageAccessException implements Exception {
  final String message;
  const StorageAccessException(this.message);

  @override
  String toString() => message;
}

class StatusOperationException implements Exception {
  final String message;
  const StatusOperationException(this.message);

  @override
  String toString() => message;
}
