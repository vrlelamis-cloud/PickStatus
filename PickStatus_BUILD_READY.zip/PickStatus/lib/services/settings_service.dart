import 'package:shared_preferences/shared_preferences.dart';

enum AppThemeMode { system, light, dark }

class SettingsService {
  static const _themeKey = 'theme';
  static const _autoScanKey = 'auto_scan';
  static const _showBusinessKey = 'show_business';

  late SharedPreferences _prefs;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
  }

  AppThemeMode get theme {
    switch (_prefs.getString(_themeKey)) {
      case 'light':
        return AppThemeMode.light;
      case 'dark':
        return AppThemeMode.dark;
      default:
        return AppThemeMode.system;
    }
  }

  bool get autoScan => _prefs.getBool(_autoScanKey) ?? true;
  bool get showBusiness => _prefs.getBool(_showBusinessKey) ?? true;

  Future<void> setTheme(AppThemeMode value) async {
    final name = switch (value) {
      AppThemeMode.light => 'light',
      AppThemeMode.dark => 'dark',
      AppThemeMode.system => 'system',
    };
    await _prefs.setString(_themeKey, name);
  }

  Future<void> setAutoScan(bool value) => _prefs.setBool(_autoScanKey, value);
  Future<void> setShowBusiness(bool value) =>
      _prefs.setBool(_showBusinessKey, value);
}
