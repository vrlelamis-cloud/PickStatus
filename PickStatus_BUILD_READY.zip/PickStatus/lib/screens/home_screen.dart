import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';

import '../models/status_item.dart';
import '../services/settings_service.dart';
import '../services/status_service.dart';

enum MediaFilter { all, images, videos }

class HomeScreen extends StatefulWidget {
  final SettingsService settings;
  final StatusService statusService;
  final VoidCallback onThemeChanged;

  const HomeScreen({
    super.key,
    required this.settings,
    required this.statusService,
    required this.onThemeChanged,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<StatusItem> _statuses = [];
  List<File> _saved = [];
  MediaFilter _filter = MediaFilter.all;
  String _query = '';
  bool _loading = true;
  bool _hasAccess = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      _hasAccess = await widget.statusService.hasStorageAccess();
      _saved = await widget.statusService.savedFiles();

      if (_hasAccess) {
        _statuses = await widget.statusService.scan(
          includeBusiness: widget.settings.showBusiness,
        );
      }
    } catch (e) {
      _error = e.toString();
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<StatusItem> get _filtered {
    return _statuses.where((item) {
      final matchesType = switch (_filter) {
        MediaFilter.all => true,
        MediaFilter.images => !item.isVideo,
        MediaFilter.videos => item.isVideo,
      };
      final q = _query.trim().toLowerCase();
      final matchesSearch = q.isEmpty || item.name.toLowerCase().contains(q);
      return matchesType && matchesSearch;
    }).toList();
  }

  bool _isSaved(StatusItem item) {
    final sourceName = p.basename(item.name);
    return _saved.any((f) => p.basename(f.path) == sourceName);
  }

  Future<void> _requestAccess() async {
    final granted = await widget.statusService.requestStorageAccess();
    if (!mounted) return;
    if (!granted) {
      _showSnack(
        'Permission refusée. Ouvre les réglages Android pour autoriser l’accès aux fichiers.',
        error: true,
      );
    }
    await _load();
  }

  Future<void> _save(StatusItem item) async {
    try {
      final file = await widget.statusService.saveStatus(item);
      await _load();
      if (mounted) {
        _showSnack('Enregistré dans Pictures/PickStatus');
      }
      debugPrint(file.path);
    } catch (e) {
      if (mounted) _showSnack(e.toString(), error: true);
    }
  }

  Future<void> _sharePath(String path) async {
    try {
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(path)],
          text: 'Partagé depuis PickStatus',
        ),
      );
    } catch (e) {
      if (mounted) _showSnack('Impossible de partager ce fichier.', error: true);
    }
  }

  Future<void> _deleteSaved(File file) async {
    final ok = await widget.statusService.deleteSaved(file.path);
    await _load();
    if (mounted) {
      _showSnack(ok ? 'Fichier supprimé.' : 'Suppression impossible.', error: !ok);
    }
  }

  void _showSnack(String text, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        behavior: SnackBarBehavior.floating,
        backgroundColor: error ? Colors.red.shade700 : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'PickStatus',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          actions: [
            IconButton(
              tooltip: 'Actualiser',
              onPressed: _loading ? null : _load,
              icon: const Icon(Icons.refresh_rounded),
            ),
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'settings') _openSettings();
                if (value == 'about') _showAbout();
              },
              itemBuilder: (_) => const [
                PopupMenuItem(
                  value: 'settings',
                  child: ListTile(
                    leading: Icon(Icons.settings_outlined),
                    title: Text('Paramètres'),
                  ),
                ),
                PopupMenuItem(
                  value: 'about',
                  child: ListTile(
                    leading: Icon(Icons.info_outline),
                    title: Text('À propos'),
                  ),
                ),
              ],
            ),
          ],
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Statuts', icon: Icon(Icons.auto_awesome_motion)),
              Tab(text: 'Enregistrés', icon: Icon(Icons.download_done)),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildStatuses(),
            _buildSaved(),
          ],
        ),
      ),
    );
  }

  Widget _buildStatuses() {
    if (!_hasAccess && !_loading) {
      return _AccessCard(onGrant: _requestAccess);
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
          child: TextField(
            onChanged: (value) => setState(() => _query = value),
            decoration: InputDecoration(
              hintText: 'Rechercher un statut…',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _query.isEmpty
                  ? null
                  : IconButton(
                      onPressed: () => setState(() => _query = ''),
                      icon: const Icon(Icons.clear),
                    ),
              filled: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              _filterChip('Tous', MediaFilter.all),
              _filterChip('Photos', MediaFilter.images),
              _filterChip('Vidéos', MediaFilter.videos),
            ],
          ),
        ),
        if (_loading)
          const Expanded(child: Center(child: CircularProgressIndicator()))
        else if (_error != null)
          Expanded(child: _ErrorCard(message: _error!, onRetry: _load))
        else if (_filtered.isEmpty)
          const Expanded(
            child: Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.photo_library_outlined, size: 64),
                    SizedBox(height: 16),
                    Text(
                      'Aucun statut trouvé',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Consulte d’abord les statuts dans WhatsApp, puis actualise PickStatus.',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          )
        else
          Expanded(
            child: RefreshIndicator(
              onRefresh: _load,
              child: GridView.builder(
                padding: const EdgeInsets.all(10),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  childAspectRatio: .72,
                ),
                itemCount: _filtered.length,
                itemBuilder: (_, index) => _StatusCard(
                  item: _filtered[index],
                  saved: _isSaved(_filtered[index]),
                  onOpen: () => _openPreview(_filtered[index]),
                  onSave: () => _save(_filtered[index]),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _filterChip(String label, MediaFilter value) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        selected: _filter == value,
        label: Text(label),
        onSelected: (_) => setState(() => _filter = value),
      ),
    );
  }

  Widget _buildSaved() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_saved.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.download_for_offline_outlined, size: 64),
              SizedBox(height: 16),
              Text(
                'Aucun statut enregistré',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                'Les statuts enregistrés apparaîtront ici.',
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.all(10),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        childAspectRatio: .72,
      ),
      itemCount: _saved.length,
      itemBuilder: (_, index) {
        final file = _saved[index];
        final ext = p.extension(file.path).toLowerCase();
        final isVideo = {'.mp4', '.3gp', '.mkv', '.webm', '.mov', '.avi'}
            .contains(ext);

        return Card(
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () => _openSavedPreview(file, isVideo),
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (isVideo)
                  Container(
                    color: Colors.black87,
                    child: const Center(
                      child: Icon(Icons.play_circle_fill, size: 58, color: Colors.white),
                    ),
                  )
                else
                  Image.file(
                    file,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const Icon(Icons.broken_image),
                  ),
                Positioned(
                  left: 8,
                  right: 8,
                  bottom: 8,
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          p.basename(file.path),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            shadows: [Shadow(blurRadius: 4)],
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () => _sharePath(file.path),
                        icon: const Icon(Icons.share, color: Colors.white),
                      ),
                      IconButton(
                        onPressed: () => _deleteSaved(file),
                        icon: const Icon(Icons.delete_outline, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _openPreview(StatusItem item) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PreviewScreen(
          path: item.sourcePath,
          isVideo: item.isVideo,
          title: item.name,
          actionLabel: _isSaved(item) ? 'Déjà enregistré' : 'Enregistrer',
          onAction: _isSaved(item) ? null : () => _save(item),
          onShare: () => _sharePath(item.sourcePath),
        ),
      ),
    );
  }

  Future<void> _openSavedPreview(File file, bool isVideo) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PreviewScreen(
          path: file.path,
          isVideo: isVideo,
          title: p.basename(file.path),
          onShare: () => _sharePath(file.path),
        ),
      ),
    );
  }

  Future<void> _openSettings() async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Paramètres',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    SwitchListTile(
                      title: const Text('WhatsApp Business'),
                      subtitle: const Text('Inclure les statuts Business dans le scan'),
                      value: widget.settings.showBusiness,
                      onChanged: (v) async {
                        await widget.settings.setShowBusiness(v);
                        setSheetState(() {});
                        await _load();
                      },
                    ),
                    SwitchListTile(
                      title: const Text('Actualisation au démarrage'),
                      value: widget.settings.autoScan,
                      onChanged: (v) async {
                        await widget.settings.setAutoScan(v);
                        setSheetState(() {});
                      },
                    ),
                    ListTile(
                      leading: const Icon(Icons.dark_mode_outlined),
                      title: const Text('Apparence'),
                      trailing: DropdownButton<AppThemeMode>(
                        value: widget.settings.theme,
                        onChanged: (value) async {
                          if (value == null) return;
                          await widget.settings.setTheme(value);
                          widget.onThemeChanged();
                          setSheetState(() {});
                        },
                        items: const [
                          DropdownMenuItem(
                            value: AppThemeMode.system,
                            child: Text('Système'),
                          ),
                          DropdownMenuItem(
                            value: AppThemeMode.light,
                            child: Text('Clair'),
                          ),
                          DropdownMenuItem(
                            value: AppThemeMode.dark,
                            child: Text('Sombre'),
                          ),
                        ],
                      ),
                    ),
                    ListTile(
                      leading: const Icon(Icons.folder_outlined),
                      title: const Text('Dossier de sauvegarde'),
                      subtitle: const Text('Pictures/PickStatus'),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showAbout() {
    showAboutDialog(
      context: context,
      applicationName: 'PickStatus',
      applicationVersion: '1.0.0',
      applicationLegalese: 'Application locale et hors connexion.',
      children: const [
        Text(
          'PickStatus détecte les médias de statut déjà présents sur le téléphone et permet de les sauvegarder et partager.',
        ),
      ],
    );
  }
}

class _AccessCard extends StatelessWidget {
  final VoidCallback onGrant;

  const _AccessCard({required this.onGrant});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.folder_open_rounded, size: 64),
                const SizedBox(height: 16),
                const Text(
                  'Accès au stockage requis',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                const Text(
                  'PickStatus doit pouvoir lire les dossiers de statuts WhatsApp et WhatsApp Business.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                FilledButton.icon(
                  onPressed: onGrant,
                  icon: const Icon(Icons.lock_open),
                  label: const Text('Autoriser l’accès'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ErrorCard extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _ErrorCard({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 56),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('Réessayer'),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final StatusItem item;
  final bool saved;
  final VoidCallback onOpen;
  final VoidCallback onSave;

  const _StatusCard({
    required this.item,
    required this.saved,
    required this.onOpen,
    required this.onSave,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onOpen,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (item.isVideo)
              Container(
                color: Colors.black87,
                child: const Center(
                  child: Icon(
                    Icons.play_circle_fill,
                    size: 62,
                    color: Colors.white,
                  ),
                ),
              )
            else
              Image.file(
                File(item.sourcePath),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    const Center(child: Icon(Icons.broken_image_outlined)),
              ),
            Positioned(
              top: 8,
              right: 8,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  item.extension,
                  style: const TextStyle(color: Colors.white, fontSize: 11),
                ),
              ),
            ),
            Positioned(
              left: 8,
              right: 8,
              bottom: 8,
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      item.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        shadows: [Shadow(blurRadius: 4)],
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: saved ? null : onSave,
                    icon: Icon(
                      saved ? Icons.check_circle : Icons.download_rounded,
                      color: Colors.white,
                    ),
                    tooltip: saved ? 'Déjà enregistré' : 'Enregistrer',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PreviewScreen extends StatefulWidget {
  final String path;
  final bool isVideo;
  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;
  final VoidCallback onShare;

  const PreviewScreen({
    super.key,
    required this.path,
    required this.isVideo,
    required this.title,
    required this.onShare,
    this.actionLabel,
    this.onAction,
  });

  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  VideoPlayerController? _controller;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();
    if (widget.isVideo) {
      _controller = VideoPlayerController.file(File(widget.path))
        ..initialize().then((_) {
          if (mounted) setState(() => _videoReady = true);
        }).catchError((_) {});
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          IconButton(
            tooltip: 'Partager',
            onPressed: widget.onShare,
            icon: const Icon(Icons.share),
          ),
        ],
      ),
      body: Center(
        child: widget.isVideo
            ? _videoReady
                ? AspectRatio(
                    aspectRatio: _controller!.value.aspectRatio == 0
                        ? 16 / 9
                        : _controller!.value.aspectRatio,
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        VideoPlayer(_controller!),
                        VideoProgressIndicator(
                          _controller!,
                          allowScrubbing: true,
                          padding: const EdgeInsets.all(12),
                        ),
                        Positioned(
                          bottom: 22,
                          child: FloatingActionButton.small(
                            onPressed: () {
                              setState(() {
                                if (_controller!.value.isPlaying) {
                                  _controller!.pause();
                                } else {
                                  _controller!.play();
                                }
                              });
                            },
                            child: Icon(
                              _controller!.value.isPlaying
                                  ? Icons.pause
                                  : Icons.play_arrow,
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                : const CircularProgressIndicator()
            : InteractiveViewer(
                minScale: .5,
                maxScale: 4,
                child: Image.file(
                  File(widget.path),
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) =>
                      const Icon(Icons.broken_image, size: 80),
                ),
              ),
      ),
      bottomNavigationBar: widget.onAction == null
          ? null
          : SafeArea(
              minimum: const EdgeInsets.all(12),
              child: FilledButton.icon(
                onPressed: widget.onAction,
                icon: const Icon(Icons.download),
                label: Text(widget.actionLabel ?? 'Enregistrer'),
              ),
            ),
    );
  }
}
