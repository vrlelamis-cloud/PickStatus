# Android setup note

This repository contains the application source and Android module configuration.
The safest way to synchronize the generated Flutter wrapper files with the exact
Flutter SDK installed on your machine is:

1. Install Flutter.
2. From this folder run:
   `flutter create --platforms=android .`
3. Re-run:
   `flutter pub get`
4. Build:
   `flutter build apk --release`

Do not overwrite `lib/`, `test/`, `pubspec.yaml`, or the custom Kotlin/manifest
files after running `flutter create`. If `flutter create` updates the Android
Gradle plugin versions to match your installed Flutter release, keep the generated
versions.
