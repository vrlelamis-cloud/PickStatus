import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:pickstatus/models/status_item.dart';

void main() {
  test('detects image status from extension', () {
    final dir = Directory.systemTemp.createTempSync('pickstatus_test_');
    final file = File('${dir.path}/status.jpg')..writeAsBytesSync([1]);
    final item = StatusItem.fromFile(file);
    expect(item.isVideo, false);
    expect(item.extension, 'JPG');
    dir.deleteSync(recursive: true);
  });

  test('detects video status from extension', () {
    final dir = Directory.systemTemp.createTempSync('pickstatus_test_');
    final file = File('${dir.path}/status.mp4')..writeAsBytesSync([1]);
    final item = StatusItem.fromFile(file);
    expect(item.isVideo, true);
    expect(item.extension, 'MP4');
    dir.deleteSync(recursive: true);
  });
}
