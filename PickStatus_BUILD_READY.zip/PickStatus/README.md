# PickStatus

Application Android Flutter permettant de détecter, prévisualiser, enregistrer et partager les statuts WhatsApp et WhatsApp Business.

## Important

PickStatus est une application locale : aucun compte, serveur, API ou clé secrète n'est nécessaire.

La version Android utilise l'accès « gérer tous les fichiers » afin de pouvoir lire les dossiers `.Statuses` de WhatsApp/WhatsApp Business sur les appareils Android modernes. Cette permission est sensible et peut être soumise à des restrictions si vous distribuez l'application sur Google Play. Pour un APK personnel/sideload, elle peut être utilisée.

## Pré-requis

- Flutter récent (Dart 3.10+).
- Android SDK avec API 35.
- Java 17.
- Android 7.0+ (API 24+).

## Installation

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

Pour un APK release :

```bash
flutter build apk --release
```

L'APK sera dans :

`build/app/outputs/flutter-apk/app-release.apk`

## Première utilisation

1. Installez PickStatus.
2. Ouvrez l'application.
3. Accordez l'accès aux fichiers lorsque Android le demande.
4. Ouvrez WhatsApp ou WhatsApp Business et consultez les statuts.
5. Revenez dans PickStatus et appuyez sur Actualiser.
6. Sélectionnez un statut puis appuyez sur Enregistrer.

## Chemins pris en charge

PickStatus recherche notamment :

- `/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.Statuses`
- `/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses`
- `/storage/emulated/0/WhatsApp/Media/.Statuses`
- `/storage/emulated/0/WhatsApp Business/Media/.Statuses`

Les constructeurs peuvent modifier ces chemins. Si WhatsApp change son stockage, le scanner pourra nécessiter une mise à jour.

## Fonctionnalités

- Photos et vidéos.
- WhatsApp et WhatsApp Business.
- Détection des nouveaux statuts.
- Enregistrement local dans `Pictures/PickStatus`.
- Galerie interne.
- Recherche.
- Filtres photo/vidéo.
- Favoris.
- Suppression.
- Partage Android.
- Aperçu vidéo.
- Mode clair/sombre/système.
- Paramètres locaux.
- Statistiques locales.
- Fonctionnement hors ligne.
- Gestion des erreurs et doublons.

## Limites

PickStatus ne contourne pas le chiffrement de WhatsApp et ne récupère pas les statuts supprimés. Il ne fonctionne que lorsque les médias sont effectivement présents dans le stockage accessible du téléphone.

Aucune authentification n'est nécessaire car les données restent sur l'appareil. Les rôles utilisateur et mots de passe sont donc volontairement absents.
