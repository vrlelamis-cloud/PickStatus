# PickStatus — build depuis Android

## Ce qu'il faut
- Un compte GitHub
- Chrome ou un navigateur sur Android
- Le fichier PickStatus_Flutter.zip
- Aucun PC nécessaire

## Étapes
1. Ouvre https://github.com et connecte-toi.
2. Crée un nouveau dépôt nommé `PickStatus`.
3. Mets-le en Public pour simplifier l'utilisation de GitHub Actions.
4. Dans le dépôt, crée le fichier `.github/workflows/build-apk.yml`.
5. Copie le contenu du fichier `build-apk.yml` fourni dans ce kit et valide avec "Commit changes".
6. Ensuite, choisis "Add file" > "Upload files" et téléverse `PickStatus_Flutter.zip`.
7. Valide le commit.
8. Ouvre l'onglet "Actions".
9. Le workflow "Build PickStatus APK" démarre automatiquement.
10. Quand il est terminé avec une coche verte, ouvre l'exécution puis la section "Artifacts".
11. Télécharge `PickStatus-APK`.
12. Décompresse l'archive téléchargée : tu trouveras `app-release.apk`.
13. Ouvre l'APK et autorise l'installation depuis cette source si Android le demande.

## Important
Le projet reste hors ligne : aucun compte PickStatus ni serveur PickStatus n'est nécessaire.
Le build est réalisé par GitHub Actions, pas par ton téléphone.
